import java.util.Iterator;
import java.util.NoSuchElementException;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
  private int siz = 0;
  private Item[] items;

  // construct an empty randomized queue
  public RandomizedQueue(){
    resizeQueue(2);
  }

  private void resizeQueue(int newCapacity) {
    Item[] newItems = (Item[]) new Object[newCapacity];
    for(int i = 0; i < siz; i++){
      newItems[i] = items[i];
    }
    items = newItems;
  }

  // is the randomized queue empty?
  public boolean isEmpty(){
    return (siz == 0);
  }

  // return the number of items on the randomized queue
  public int size(){
    return siz;
  }

  // add the item
  public void enqueue(Item item){
    if( item == null ) throw new IllegalArgumentException();
    items[siz++] = item;
    if(siz == items.length) {
      resizeQueue(items.length * 2);
    }
  }

  // remove and return a random item
  public Item dequeue() {
    if(isEmpty()) throw new NoSuchElementException();
    int chosenIndex = StdRandom.uniformInt(siz);
    Item temp = items[chosenIndex];
    items[chosenIndex] = items[siz-1];
    items[--siz] = null;
    if(siz == items.length / 4 && siz > 0 ) {
      resizeQueue((items.length/4)*2);
    }
    return temp;
  }

  // return a random item (but do not remove it)
  public Item sample() {
    if(isEmpty()) throw new NoSuchElementException();
    return items[ StdRandom.uniformInt(siz) ];
  }

  private class RandomizedIterator implements Iterator<Item> {
    int[] permutationIndex = new int[siz];
    int cur = 0;
    RandomizedIterator() {
      for(int i = 0; i < siz; i++) {
        permutationIndex[i] = i;
      }
      StdRandom.shuffle(permutationIndex);
    }

    @Override
    public boolean hasNext() {
      return ( cur < siz );
    }

    @Override
    public Item next() {
      if(!hasNext()) throw new NoSuchElementException();
      return items[permutationIndex[cur++]];
    }
  }

  // return an independent iterator over items in random order
  public Iterator<Item> iterator() {
    return new RandomizedIterator();
  }

  // unit testing (required)

  public static void main(String[] args) {
    RandomizedQueue<Integer> queue = new RandomizedQueue<>();
    queue.enqueue(1);
    System.out.println(queue.isEmpty());
    queue.enqueue(11);
    System.out.println(queue.dequeue());
    System.out.println(queue.dequeue());
  }
}
